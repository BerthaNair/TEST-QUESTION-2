/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.runapplication_question2;

/**
 *
 * @author Student
 */
public abstract class Consoles implements iConsoles {
    private String ConsoleType;
    private String Store;
    private int totalSales;
    
      public Consoles(String deviceType, String storeName ,int totalSales){
        this.ConsoleType = deviceType;
        this.Store = storeName;
        this.totalSales = totalSales;
                
         
  }
    @Override
       public String getConsoleType() {
        return ConsoleType;
    }
    @Override
        public String  getStore() {
        return Store;
    }

    @Override
        public int getTotalSales() {
        return totalSales;
    }
 
    
}

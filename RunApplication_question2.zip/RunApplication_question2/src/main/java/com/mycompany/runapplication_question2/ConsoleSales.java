/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.runapplication_question2;

/**
 *
 * @author Student
 */
public class ConsoleSales extends Consoles{
      public ConsoleSales(String deviceType ,String storeName, int totalSales ){
            super(deviceType, storeName, totalSales);
      }
      
      public void printReport(){
           System.out.println("*********************");
           System.out.println("CONSOLE TYPE :" + getConsoleType());
           System.out.println(" STORE NAME:" + getStore());
           System.out.println("TOTAL SALES " + (int) getTotalSales());
           System.out.println("*********************");
      }
      
    
}

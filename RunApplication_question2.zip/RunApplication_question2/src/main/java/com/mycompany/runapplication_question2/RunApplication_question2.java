/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.runapplication_question2;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class RunApplication_question2 {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
    
      
            try{
       
            System.out.println("Select the beverage type ");
            System.out.println("1. PS5");
            System.out.println("2. XBOX");
            System.out.println("3.SWITCH");
           
            System.out.print("Enter choice");
            int choice = input.nextInt();
            input.nextLine();
            
            System.out.print("Enter the Store :");
            String Store =input.nextLine();
                    
            System.out.print("Enter the total sales of PS5 consoles for Number 1 Electronics Store ");
            int totalSales = input.nextInt();
            
            switch(choice){
                case 1:
                  PS5 ps = new PS5(Store , totalSales);
                  
                  System.out.println("Store :" + ps.getStore());
                  System.out.println("TOTAL SALES : R" + ps.getTotalSales);
                     break; 
                     
                case 2:
                   XBOX xbox = new XBOX(Store , totalSales);
                  
                  System.out.println("Store :" + xbox.getStore());
                  System.out.println("TOTAL SALES : R" + xbox.getTotalSales);
                    break;
                    
                case 3:
                   SWITCH switchgame = new switchgame (Store , totalSales);
                  
                  System.out.println("Store :" + switchgame.getStore());
                  System.out.println("TOTAL SALES : R" + switchgame.getTotalSales);
                    break;
                    
                    
                       default:
                    System.out.println("Invalid cosole type ");
                    
                    
            }
            }catch(Exception e){
                System.out.println("invalid input. Please enter correct input");
            }
                    
    }
}

    
        

